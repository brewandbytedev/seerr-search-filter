// src/options/options.ts
var form = document.getElementById("add-form");
var input = document.getElementById("origin-input");
var list = document.getElementById("origin-list");
var statusEl = document.getElementById("status-msg");
var addBtn = document.getElementById("add-btn");
var versionEl = document.getElementById("ext-version");
versionEl.textContent = chrome.runtime.getManifest().version;
function showStatus(kind, message) {
  statusEl.textContent = message;
  statusEl.className = `status visible ${kind}`;
}
function normalizeOrigin(raw) {
  try {
    const url = new URL(raw);
    if (url.protocol !== "http:" && url.protocol !== "https:") return null;
    return url.origin;
  } catch {
    return null;
  }
}
async function getOrigins() {
  const { instanceOrigins } = await chrome.storage.sync.get("instanceOrigins");
  return instanceOrigins ?? [];
}
async function setOrigins(origins) {
  await chrome.storage.sync.set({ instanceOrigins: origins });
}
function render(origins) {
  list.innerHTML = "";
  for (const origin of origins) {
    const li = document.createElement("li");
    const span = document.createElement("span");
    span.className = "origin-url";
    span.textContent = origin;
    const removeBtn = document.createElement("button");
    removeBtn.type = "button";
    removeBtn.textContent = "Remove";
    removeBtn.addEventListener("click", () => void removeOrigin(origin));
    li.append(span, removeBtn);
    list.append(li);
  }
}
async function addOrigin(origin) {
  addBtn.disabled = true;
  showStatus("info", "Requesting permission\u2026");
  try {
    const granted = await chrome.permissions.request({ origins: [`${origin}/*`] });
    if (!granted) {
      showStatus("error", "Permission was not granted, so the filter toolbar cannot run on that site.");
      return;
    }
    const origins = await getOrigins();
    if (!origins.includes(origin)) {
      origins.push(origin);
      await setOrigins(origins);
    }
    await chrome.runtime.sendMessage({ type: "seerr-search-filter:add-origin", origin });
    render(origins);
    showStatus("success", `Added ${origin}.`);
  } finally {
    addBtn.disabled = false;
  }
}
async function removeOrigin(origin) {
  const origins = (await getOrigins()).filter((o) => o !== origin);
  await setOrigins(origins);
  await chrome.permissions.remove({ origins: [`${origin}/*`] }).catch(() => {
  });
  await chrome.runtime.sendMessage({ type: "seerr-search-filter:remove-origin", origin });
  render(origins);
  showStatus("info", `Removed ${origin}.`);
}
form.addEventListener("submit", (event) => {
  event.preventDefault();
  const origin = normalizeOrigin(input.value.trim());
  if (!origin) {
    showStatus("error", "Enter a valid http(s) URL, e.g. http://192.168.1.10:5055");
    return;
  }
  input.value = "";
  void addOrigin(origin);
});
void getOrigins().then(render);
//# sourceMappingURL=options.js.map
