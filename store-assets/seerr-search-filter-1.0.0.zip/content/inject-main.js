"use strict";
(() => {
  // src/types.ts
  var BRIDGE_MESSAGE_SOURCE = "seerr-search-filter";

  // src/content/inject-main.ts
  function post(message) {
    window.postMessage(message, window.location.origin);
  }
  async function inspectSearchResponse(url, response) {
    if (!response.ok || !url.includes("/api/v1/search")) return;
    try {
      const payload = await response.clone().json();
      post({ source: BRIDGE_MESSAGE_SOURCE, kind: "search", payload });
    } catch {
    }
  }
  var originalFetch = window.fetch.bind(window);
  window.fetch = async (...args) => {
    const response = await originalFetch(...args);
    const url = typeof args[0] === "string" ? args[0] : args[0].url ?? String(args[0]);
    void inspectSearchResponse(url, response);
    return response;
  };
  var originalOpen = XMLHttpRequest.prototype.open;
  XMLHttpRequest.prototype.open = function patchedOpen(method, url, ...rest) {
    const href = typeof url === "string" ? url : url.toString();
    if (href.includes("/api/v1/search")) {
      this.addEventListener("load", () => {
        try {
          const payload = JSON.parse(this.responseText);
          post({ source: BRIDGE_MESSAGE_SOURCE, kind: "search", payload });
        } catch {
        }
      });
    }
    return originalOpen.call(this, method, url, ...rest);
  };
})();
//# sourceMappingURL=inject-main.js.map
