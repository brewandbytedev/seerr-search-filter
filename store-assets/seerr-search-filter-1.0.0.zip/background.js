// src/background.ts
var REGISTERED_ID_PREFIX = "seerr-search-filter";
async function getStoredOrigins() {
  const { instanceOrigins } = await chrome.storage.sync.get("instanceOrigins");
  return instanceOrigins ?? [];
}
async function registerForOrigin(origin) {
  const id = `${REGISTERED_ID_PREFIX}:${origin}`;
  const existing = await chrome.scripting.getRegisteredContentScripts({ ids: [id] });
  if (existing.length > 0) {
    await chrome.scripting.unregisterContentScripts({ ids: [id] });
  }
  const matches = [`${origin}/search*`, `${origin}/person/*`];
  await chrome.scripting.registerContentScripts([
    {
      id,
      matches,
      js: ["content/inject-main.js"],
      world: "MAIN",
      runAt: "document_start"
    },
    {
      id: `${id}:panel`,
      matches,
      js: ["content/panel.js"],
      world: "ISOLATED",
      runAt: "document_idle"
    }
  ]);
}
async function unregisterForOrigin(origin) {
  const id = `${REGISTERED_ID_PREFIX}:${origin}`;
  await chrome.scripting.unregisterContentScripts({ ids: [id, `${id}:panel`] }).catch(() => {
  });
}
async function syncAllRegistrations() {
  const origins = await getStoredOrigins();
  const registered = await chrome.scripting.getRegisteredContentScripts();
  const staleIds = registered.map((s) => s.id).filter((id) => id.startsWith(REGISTERED_ID_PREFIX) && !origins.some((o) => id.includes(o)));
  if (staleIds.length > 0) {
    await chrome.scripting.unregisterContentScripts({ ids: staleIds });
  }
  for (const origin of origins) {
    await registerForOrigin(origin);
  }
}
chrome.runtime.onInstalled.addListener((details) => {
  void syncAllRegistrations();
  if (details.reason === "install") {
    void chrome.runtime.openOptionsPage();
  }
});
chrome.runtime.onStartup.addListener(() => {
  void syncAllRegistrations();
});
chrome.action.onClicked.addListener(() => {
  void chrome.runtime.openOptionsPage();
});
chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.type === "seerr-search-filter:add-origin") {
    void registerForOrigin(message.origin).then(() => sendResponse({ ok: true }));
    return true;
  }
  if (message?.type === "seerr-search-filter:remove-origin") {
    void unregisterForOrigin(message.origin).then(() => sendResponse({ ok: true }));
    return true;
  }
  return false;
});
//# sourceMappingURL=background.js.map
